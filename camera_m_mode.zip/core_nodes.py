class Camera_MMode_Core:
    def __init__(self):
        pass

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "aperture": ([
                    "f/1.0", "f/1.2", "f/1.4", "f/1.8",
                    "f/2.0", "f/2.8", "f/4.0", "f/5.6",
                    "f/8.0", "f/11", "f/16", "f/22"
                ], {"default": "f/2.8"}),

                "shutter_speed": ([
                    "1/8000", "1/4000", "1/2000", "1/1000",
                    "1/500", "1/250", "1/125", "1/60",
                    "1/30", "1/15", "1/8", "1/4", "1/2", "1s"
                ], {"default": "1/125"}),

                "iso": ([
                    "50", "100", "200", "400", "800",
                    "1600", "3200", "6400", "12800", "25600"
                ], {"default": "200"}),

                "ev_comp": ([
                    "-3.0", "-2.0", "-1.0", "-0.7", "-0.3",
                    "0", "+0.3", "+0.7", "+1.0", "+2.0", "+3.0"
                ], {"default": "0"}),

                "focus_mode": (["Auto Focus", "Manual Focus", "Eye Focus", "Background Blur"],),
                "white_balance": (["Auto", "Daylight", "Cloudy", "Warm", "Cool"],),
                "style_preset": (["General", "Virtual Idol", "Portrait", "Night", "Cinematic"],),
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("camera_prompt",)
    FUNCTION = "generate"
    CATEGORY = "CustomCamera/MMode"

    def generate(self, aperture, shutter_speed, iso, ev_comp, focus_mode, white_balance, style_preset):
        # 數值對照表
        import re
        f_num = float(re.sub(r'[^\d.]', '', aperture))
        iso_val = int(iso)
        ev_val = float(ev_comp)

        # 快門對應數值
        shutter_map = {
            "1/8000": 1/8000, "1/4000": 1/4000, "1/2000": 1/2000, "1/1000": 1/1000,
            "1/500": 1/500, "1/250": 1/250, "1/125": 1/125, "1/60": 1/60,
            "1/30": 1/30, "1/15": 1/15, "1/8": 1/8, "1/4": 1/4, "1/2": 1/2, "1s": 1.0
        }
        t = shutter_map[shutter_speed]

        # 輸出用
        shutter_out = shutter_speed + "s"
        ev_out = f"{ev_comp}EV" if ev_val < 0 else f"+{ev_comp}EV" if ev_val > 0 else ""

        # 景深
        if f_num <= 2.8:
            dof = "shallow depth of field, bokeh"
        elif f_num <= 5.6:
            dof = "medium depth of field"
        else:
            dof = "deep depth of field, sharp"

        # 動態
        if t < 1/30:
            motion = "motion blur, long exposure"
        elif t > 1/200:
            motion = "frozen motion, sharp action"
        else:
            motion = "natural motion"

        # 雜訊
        if iso_val <= 400:
            noise = "clean, sharp, no noise"
        elif iso_val <= 1600:
            noise = "cinematic grain"
        else:
            noise = "film grain, moody"

        focus = {
            "Auto Focus": "auto focus",
            "Manual Focus": "manual focus",
            "Eye Focus": "eye focus, sharp eyes",
            "Background Blur": "strong background blur"
        }[focus_mode]

        wb = {
            "Auto": "auto white balance",
            "Daylight": "daylight white balance",
            "Cloudy": "cloudy white balance",
            "Warm": "warm tone",
            "Cool": "cool tone"
        }[white_balance]

        style = {
            "General": "",
            "Virtual Idol": "soft lighting, perfect skin, vibrant color, masterpiece",
            "Portrait": "portrait photography, soft light, smooth skin",
            "Night": "night photography, bokeh lights, moody",
            "Cinematic": "cinematic shot, cinematic color grading"
        }[style_preset]

        prompt = f"shot on DSLR, {aperture}, {shutter_out}, ISO {iso}, {ev_out}, {focus}, {wb}, {dof}, {motion}, {noise}, {style}"
        return (prompt,)

NODE_CLASS_MAPPINGS = {
    "Camera_MMode_Core": Camera_MMode_Core
}
NODE_DISPLAY_NAME_MAPPINGS = {
    "Camera_MMode_Core": "Camera M-Mode Core"
}