class Camera_MMode_Pro:
    def __init__(self):
        pass

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "aperture": ([
                    "f/1.0", "f/1.2", "f/1.4", "f/1.8",
                    "f/2.0", "f/2.8", "f/4.0", "f/5.6",
                    "f/8.0", "f/11", "f/16", "f/22"
                ], {"default": "f/2.8"}),

                "shutter_speed": ([
                    "1/8000", "1/4000", "1/2000", "1/1000",
                    "1/500", "1/250", "1/125", "1/60",
                    "1/30", "1/15", "1/8", "1/4", "1/2", "1s"
                ], {"default": "1/125"}),

                "iso": ([
                    "50", "100", "200", "400", "800",
                    "1600", "3200", "6400", "12800", "25600"
                ], {"default": "200"}),

                "ev_comp": ([
                    "-3.0", "-2.0", "-1.0", "-0.7", "-0.3",
                    "0", "+0.3", "+0.7", "+1.0", "+2.0", "+3.0"
                ], {"default": "0"}),

                "focus_mode": (["Auto Focus", "Manual Focus", "Eye Focus", "Background Blur"],),
                "white_balance": (["Auto", "Daylight", "Cloudy", "Warm", "Cool"],),
                "style_preset": (["General", "Virtual Idol", "Portrait", "Night", "Cinematic"],),
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("camera_prompt",)
    FUNCTION = "generate"
    CATEGORY = "CustomCamera/MMode"

    def generate(self, aperture, shutter_speed, iso, ev_comp, focus_mode, white_balance, style_preset):
        import re
        f_num = float(re.sub(r'[^\d.]', '', aperture))
        iso_val = int(iso)
        ev_val = float(ev_comp)

        shutter_map = {
            "1/8000": 1/8000, "1/4000": 1/4000, "1/2000": 1/2000, "1/1000": 1/1000,
            "1/500": 1/500, "1/250": 1/250, "1/125": 1/125, "1/60": 1/60,
            "1/30": 1/30, "1/15": 1/15, "1/8": 1/8, "1/4": 1/4, "1/2": 1/2, "1s": 1.0
        }
        t = shutter_map[shutter_speed]

        shutter_out = shutter_speed + "s"
        ev_out = f"{ev_comp}EV" if ev_val < 0 else f"+{ev_comp}EV" if ev_val > 0 else ""

        # 专业描述词（给AI看）
        if f_num <= 1.4:
            dof = "extremely shallow depth of field, strong bokeh, dreamy background"
        elif f_num <= 2.8:
            dof = "shallow depth of field, beautiful bokeh, soft background"
        elif f_num <= 5.6:
            dof = "medium depth of field, subject sharp, background slightly blurred"
        else:
            dof = "deep depth of field, everything sharp, clear details"

        if t < 1/30:
            motion = "long exposure, smooth motion blur, flowing light trails"
        elif t > 1/200:
            motion = "fast shutter speed, frozen motion, sharp action, no blur"
        else:
            motion = "natural motion, slight movement, realistic flow"

        if iso_val <= 400:
            noise = "ultra clean, sharp details, no noise, pristine image"
        elif iso_val <= 1600:
            noise = "clean image, subtle film grain, warm texture"
        elif iso_val <= 6400:
            noise = "cinematic grain, moody texture, soft noise"
        else:
            noise = "strong film grain, gritty mood, vintage look"

        focus = {
            "Auto Focus": "auto focus, sharp subject, quick focus",
            "Manual Focus": "manual focus, precise focus point, intentional blur",
            "Eye Focus": "eye focus, sharp eyes, detailed facial features",
            "Background Blur": "strong background blur, subject isolated, bokeh effect"
        }[focus_mode]

        wb = {
            "Auto": "auto white balance, natural color",
            "Daylight": "daylight white balance, cool tone, bright white",
            "Cloudy": "cloudy white balance, warm tone, soft light",
            "Warm": "warm tone, golden hour, orange tint",
            "Cool": "cool tone, blue tint, moonlight feel"
        }[white_balance]

        style = {
            "General": "",
            "Virtual Idol": "soft lighting, perfect skin, vibrant color, masterpiece, anime style",
            "Portrait": "portrait photography, soft light, smooth skin, shallow depth of field",
            "Night": "night photography, bokeh lights, moody, low light, dark atmosphere",
            "Cinematic": "cinematic shot, cinematic color grading, dramatic lighting, film look"
        }[style_preset]

        # 最终prompt：参数 + 描述词，AI更容易理解
        prompt_parts = [
            f"shot on DSLR, {aperture}, {shutter_out}, ISO {iso}",
            ev_out,
            focus,
            wb,
            dof,
            motion,
            noise,
            style
        ]
        # 过滤空字符串
        prompt = ", ".join([p for p in prompt_parts if p.strip()])
        return (prompt,)

NODE_CLASS_MAPPINGS = {
    "Camera_MMode_Pro": Camera_MMode_Pro
}
NODE_DISPLAY_NAME_MAPPINGS = {
    "Camera_MMode_Pro": "Camera M-Mode Pro"
}